//
//  DLDragonAssistant.h
//  DLDragonAssistant
//

#import <Foundation/Foundation.h>

//! Project version number for DLDragonAssistant.
FOUNDATION_EXPORT double DLDragonAssistantVersionNumber;

//! Project version string for DLDragonAssistant.
FOUNDATION_EXPORT const unsigned char DLDragonAssistantVersionString[];
