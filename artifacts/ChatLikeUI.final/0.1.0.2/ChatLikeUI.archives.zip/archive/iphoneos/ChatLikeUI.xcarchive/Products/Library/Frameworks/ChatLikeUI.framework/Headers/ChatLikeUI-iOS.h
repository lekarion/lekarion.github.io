//
//  ChatLikeUI-iOS.h
//  ChatLikeUI-iOS
//
//  Created by developer on 15.06.2023.
//

#import <Foundation/Foundation.h>

//! Project version number for ChatLikeUI-iOS.
FOUNDATION_EXPORT double ChatLikeUI_iOSVersionNumber;

//! Project version string for ChatLikeUI-iOS.
FOUNDATION_EXPORT const unsigned char ChatLikeUI_iOSVersionString[];
