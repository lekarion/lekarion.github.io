//
//  DLImageAssistant.h
//  DLImageAssistant
//

#import <Foundation/Foundation.h>

//! Project version number for DLImageAssistant.
FOUNDATION_EXPORT double DLImageAssistantVersionNumber;

//! Project version string for DLImageAssistant.
FOUNDATION_EXPORT const unsigned char DLImageAssistantVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DLImageAssistant/PublicHeader.h>
