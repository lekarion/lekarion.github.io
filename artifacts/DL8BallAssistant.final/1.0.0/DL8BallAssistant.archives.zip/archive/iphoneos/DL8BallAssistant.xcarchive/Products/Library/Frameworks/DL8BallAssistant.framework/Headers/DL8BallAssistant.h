//
//  DL8BallAssistant.h
//  DL8BallAssistant
//

#import <Foundation/Foundation.h>

//! Project version number for DL8BallAssistant.
FOUNDATION_EXPORT double DL8BallAssistantVersionNumber;

//! Project version string for DL8BallAssistant.
FOUNDATION_EXPORT const unsigned char DL8BallAssistantVersionString[];
