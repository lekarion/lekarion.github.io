//
//  DragonSDK.h
//  DragonSDK
//
//  Created by developer on 21.09.2022.
//  Copyright © 2022 Oleg Yaros. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DragonSDK.
FOUNDATION_EXPORT double DragonSDKVersionNumber;

//! Project version string for DragonSDK.
FOUNDATION_EXPORT const unsigned char DragonSDKVersionString[];
