//
//  OnPackagesAPI.h
//  OnPackagesAPI
//
//  Created by developer on 12.09.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for OnPackagesAPI.
FOUNDATION_EXPORT double OnPackagesAPIVersionNumber;

//! Project version string for OnPackagesAPI.
FOUNDATION_EXPORT const unsigned char OnPackagesAPIVersionString[];
